create view is_student as
select `hyf`.`s`.`sno` AS `sno`, `hyf`.`s`.`sname` AS `sname`, `hyf`.`s`.`sex` AS `sex`
from `hyf`.`s`
where (`hyf`.`s`.`sdept` = '计算机');

