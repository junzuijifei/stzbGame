create view v_female2 as
select `hyf`.`is_student`.`sno` AS `sno`, `hyf`.`is_student`.`sname` AS `sname`
from `hyf`.`is_student`
where (`hyf`.`is_student`.`sex` = '男');

