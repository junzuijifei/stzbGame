create view two_view as
select `teach6`.`sc`.`sno` AS `sno`, `teach6`.`sc`.`cno` AS `cno`, `teach6`.`sc`.`grade` AS `grade`
from `teach6`.`sc`
group by `teach6`.`sc`.`cno`
having (count(`teach6`.`sc`.`cno`) > 2);

