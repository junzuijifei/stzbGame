create view sex_view as
select count((`teach6`.`s`.`sex` = '女')) AS `count(sex='女')`,
       count((`teach6`.`s`.`sex` = '男')) AS `count(sex='男')`
from `teach6`.`s`;

