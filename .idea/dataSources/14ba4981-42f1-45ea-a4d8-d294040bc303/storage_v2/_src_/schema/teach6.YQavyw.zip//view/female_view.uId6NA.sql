create view female_view as
select `teach6`.`s`.`sno` AS `sno`, `teach6`.`s`.`sname` AS `sname`, `teach6`.`s`.`sex` AS `sex`
from `teach6`.`s`
where ((`teach6`.`s`.`sdept` = '计算机') and (`teach6`.`s`.`sex` = '女'));

