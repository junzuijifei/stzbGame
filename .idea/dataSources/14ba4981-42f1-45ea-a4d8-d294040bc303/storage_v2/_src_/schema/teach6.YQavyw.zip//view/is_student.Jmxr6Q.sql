create view is_student as
select `teach6`.`s`.`sno` AS `sno`, `teach6`.`s`.`sname` AS `sname`, `teach6`.`s`.`sex` AS `sex`
from `teach6`.`s`
where (`teach6`.`s`.`sdept` = '计算机');

