create view v_female2 as
select `teach6`.`is_student`.`sno` AS `sno`, `teach6`.`is_student`.`sname` AS `sname`
from `teach6`.`is_student`
where (`teach6`.`is_student`.`sex` = '男');

