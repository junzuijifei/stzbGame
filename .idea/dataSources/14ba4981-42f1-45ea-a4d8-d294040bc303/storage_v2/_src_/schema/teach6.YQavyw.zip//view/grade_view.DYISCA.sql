create view grade_view as
select `teach6`.`s`.`sno`    AS `sno`,
       `teach6`.`s`.`sname`  AS `sname`,
       `teach6`.`sc`.`cno`   AS `cno`,
       `teach6`.`c`.`cname`  AS `cname`,
       `teach6`.`sc`.`grade` AS `grade`
from `teach6`.`s`
         join `teach6`.`c`
         join `teach6`.`sc`
where ((`teach6`.`s`.`sno` = `teach6`.`sc`.`sno`) and (`teach6`.`c`.`cno` = `teach6`.`sc`.`cno`) and
       (`teach6`.`sc`.`grade` < 60));

