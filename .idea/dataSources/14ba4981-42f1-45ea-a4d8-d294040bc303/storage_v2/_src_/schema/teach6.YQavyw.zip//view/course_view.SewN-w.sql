create view course_view as
select `teach6`.`c`.`cno` AS `cno`, `teach6`.`c`.`cname` AS `cname`
from `teach6`.`c`;

