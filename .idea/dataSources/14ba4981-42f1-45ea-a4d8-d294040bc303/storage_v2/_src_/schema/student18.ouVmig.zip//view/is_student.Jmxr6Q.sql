create view is_student as
select `student18`.`s`.`sno` AS `sno`, `student18`.`s`.`sname` AS `sname`, `student18`.`s`.`sex` AS `sex`
from `student18`.`s`
where (`student18`.`s`.`sdept` = '计算机');

