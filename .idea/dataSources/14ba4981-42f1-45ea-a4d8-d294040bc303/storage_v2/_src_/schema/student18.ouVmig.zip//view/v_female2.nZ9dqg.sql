create view v_female2 as
select `student18`.`is_student`.`sno` AS `sno`, `student18`.`is_student`.`sname` AS `sname`
from `student18`.`is_student`
where (`student18`.`is_student`.`sex` = '男');

